<link type="text/css" rel="stylesheet" href="assets/ckeditor/bootstrap.css">

<style type="text/css">
  *{margin:0;padding:0;font-family: "Times New Roman";font-size:15px}
  table, th, td {
    border: 1px solid;
  }
  table {
    border-collapse: collapse;
  }
  p{margin:0 30px 0 45px; padding:0}
  table{margin:0 40px 0 45px; width: 750px !important;}

  .page_break { page-break-before: always; }
</style>
<div style="margin-left:10px;">
  <?php echo $html_content ?>
</div>